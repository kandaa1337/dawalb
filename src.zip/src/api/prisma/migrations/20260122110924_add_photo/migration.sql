-- AlterTable
ALTER TABLE "Drug" ADD COLUMN "photo" TEXT;
